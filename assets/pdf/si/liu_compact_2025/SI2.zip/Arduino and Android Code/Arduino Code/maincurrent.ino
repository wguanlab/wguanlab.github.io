
////////////////////////// Libraries //////////////////////////
#include <Wire.h>
//#include "Adafruit_TCS34725softi2c.h"
//#include <RunningAverage.h>
#include <SoftwareSerial.h>
//#include "Adafruit_VCNL4010.h"
#include <avr/wdt.h>
#include <Arduino.h>
#include <SPI.h>
#include <Adafruit_NeoPixel.h>
#ifdef __AVR__
#include <avr/power.h>  // Required for 16 MHz Adafruit Trinket
#endif


//PID
#include <PID_v1.h>


// Bluetooth define
#include "Adafruit_BLE.h"
#include "Adafruit_BluefruitLE_SPI.h"
#include "Adafruit_BluefruitLE_UART.h"
#include "BluefruitConfig.h"
#include <avr/io.h>
#include <util/delay.h>

// Color sensor
#include <Adafruit_AS7341.h>
#include "Wire.h"

#define TCAADDR 0x70
Adafruit_AS7341 as7341;
void tcaselect(uint8_t i) {
  if (i > 7) return;
 
  Wire.beginTransmission(TCAADDR);
  Wire.write(1 << i);
  Wire.endTransmission();   
}

#if SOFTWARE_SERIAL_AVAILABLE
  #include <SoftwareSerial.h>
#endif 
#include <Adafruit_NeoPixel.h>
#ifdef __AVR__
#include <avr/power.h>  // Required for 16 MHz Adafruit Trinket
#endif

//LED


#define PIN_NEO_PIXEL 9  // Arduino pin that connects to NeoPixel
#define NUM_PIXELS 30    // The number of LEDs (pixels) on NeoPixel
#define DELAY_INTERVAL 250  // 250ms pause between each pixel
Adafruit_NeoPixel NeoPixel(NUM_PIXELS, PIN_NEO_PIXEL, NEO_GRB + NEO_KHZ800);




////////////////////////// Pins, Constants, Variables, Objects //////////////////////////
// Bluetooth define
#define FACTORYRESET_ENABLE         1
#define MINIMUM_FIRMWARE_VERSION    "0.6.6"
#define MODE_LED_BEHAVIOUR          "MODE"


// ble

    #define FACTORYRESET_ENABLE         1
    #define MINIMUM_FIRMWARE_VERSION    "0.6.6"
    #define MODE_LED_BEHAVIOUR          "MODE"
/*=========================================================================*/

// Create the bluefruit object, either software serial...uncomment these lines
Adafruit_BluefruitLE_SPI ble(BLUEFRUIT_SPI_CS, BLUEFRUIT_SPI_IRQ, BLUEFRUIT_SPI_RST);

void error(const __FlashStringHelper*err) {
  Serial.println(err);
  while (1);
}



// You can use any digital pin for emulate SDA / SCL (color sensor)

//#define SDApin2 A1
//#define SCLpin2 A3
//#define SDApin3 A4
//#define SCLpin3 A5




/* begincommand*/
int databegin;
/*Status Timer*/
int timer =0; //120
int timer0=0;//3000
int timer1 =0;//8000
int timer2 =0;//300
int choose =0;



/* STATUS LED */
#define SLED1  A3
#define SLED2  5
#define SLED3  4
#define SLED4  3
#define SLED5  2
int brightness = 0;

/* heating colling */
#define FAN 10
#define HEATER 6   
//#define PIDOUT A2   
#define THERMISTOR A0

#define THERMISTORNOMINAL 10000      
#define TEMPERATURENOMINAL 25  
#define NUMSAMPLES 5
#define BCOEFFICIENT 3969
#define SERIESRESISTOR 10000    
#define Temp_Buffer 0
float temperature_read (const int);


/* heating colling tem */
int Acycle ;
int ATempA, ATempB, ATempC, ATempD, ATempE;
int ATimeA, ATimeB, ATimeC, ATimeD, ATimeE;
    
    
unsigned long lastSensorReadTime = 0;
bool neoPixelActiveR = false;
unsigned long neoPixelStartTimeR = 0;
bool neoPixelActiveG = false;
unsigned long neoPixelStartTimeG = 0;
bool neoPixelActiveB = false;
unsigned long neoPixelStartTimeB = 0;


////////////////////////////////////////////////////////////////////////////////
const int neoPixelDuration = 500; // 一秒
unsigned long neoPixelStartTime;
bool neoPixelActive = false;
const int sensorCount = 4;
const int channelCount = 10;
int sensorData[sensorCount][channelCount][3];


int sensor,channel,color;
//int sensorData[];


int sensorData1[channelCount][3];
int sensorData2[channelCount][3];
int sensorData3[channelCount][3];
int sensorData4[channelCount][3];



/* Initialise with specific int time and gain values color sensor  */
unsigned int r1, g1, b1, c1;
unsigned int r2, g2, b2, c2;
unsigned int r3, g3, b3, c3;
unsigned int r4, g4, b4, c4;
unsigned int f11, f21, f31, f41, f51, f61, f71, f81, f91, f01;
unsigned int f12, f22, f32, f42, f52, f62, f72, f82, f92, f02;
unsigned int f13, f23, f33, f43, f53, f63, f73, f83, f93, f03;
unsigned int f14, f24, f34, f44, f54, f64, f74, f84, f94, f04;
unsigned int rbg1, gbg1, bbg1, cbg1;
unsigned int rbg2, gbg2, bbg2, cbg2;
unsigned int rbg3, gbg3, bbg3, cbg3;
uint16_t rcor1, rcor2, rcor3, gcor1, gcor2, gcor3, bcor1, bcor2, bcor3;



/* amplification */
const int amplificationTimeInMinutes = 60;
const int amplificationTimeInSec = amplificationTimeInMinutes * 60;
const int bgCheckIter = 10;
const int tempBuffer = 0; // +/-
const int TIMESPAN = 10; // 10 data points for moving average


String inputString ;     // 用于缓存输入的字符串
bool stringComplete = false; // 标记字符串是否接收完成



///PID
int heaterOutput = 0;
int fanOutput = 0;
int PPIDOutput = 0;

double Setpoint, Input, Output;
double Kp = 100, Ki = 0.8, Kd = 400; // 这些参数需要根据您的系统进行调整

PID myPID(&Input, &Output, &Setpoint, Kp, Ki, Kd, DIRECT);
//PID myPID(&Input, &Output, &Setpoint, Kp, Ki, Kd, REVERSE);

////////////////////////// Set up //////////////////////////
void setup() {
  Serial.begin(9600);

  /*detector switch*/
    analogReference(EXTERNAL);
  /* INDICATOR LED */
  pinMode(SLED1, OUTPUT);
  pinMode(SLED2, OUTPUT);
  pinMode(SLED3, OUTPUT);
  pinMode(SLED4, OUTPUT);
  pinMode(SLED5, OUTPUT);
  digitalWrite(SLED1, HIGH);
  digitalWrite(SLED2, HIGH);
  digitalWrite(SLED3, HIGH);
  digitalWrite(SLED4, HIGH);
  digitalWrite(SLED5, HIGH);

  delay(800);

  digitalWrite(SLED1, HIGH);
  digitalWrite(SLED2, LOW);
  digitalWrite(SLED3, LOW);
  digitalWrite(SLED4, LOW);
  digitalWrite(SLED5, LOW);

 
  /* heating */
  pinMode(HEATER, OUTPUT);
//  pinMode(PIDOUT, OUTPUT);
  pinMode(THERMISTOR, INPUT);
  pinMode(FAN, OUTPUT);
  digitalWrite(FAN, LOW);
  digitalWrite(HEATER, LOW);
//  digitalWrite(PIDOUT, LOW);
  


NeoPixel.begin();
 
 /* check color sensor*/

  
     Wire.begin();

      tcaselect(2);
 
      Serial.print("TCA Port #"); Serial.println(0);

      for (uint8_t addr = 0; addr<=127; addr++) {
        if (addr == TCAADDR) continue;

        Wire.beginTransmission(addr);
        if (!Wire.endTransmission()) {
          Serial.print("Found I2C 0x");  Serial.println(addr,HEX);
        }
      }

      if (!as7341.begin()){
               Serial.println("find 1");

               
              }


      tcaselect(3);

      Serial.print("TCA Port #"); Serial.println(1);

      for (uint8_t addr = 0; addr<=127; addr++) {
        if (addr == TCAADDR) continue;

        Wire.beginTransmission(addr);
        if (!Wire.endTransmission()) {
          Serial.print("Found I2C 0x");  Serial.println(addr,HEX);
        }
      }

      if (!as7341.begin()){
               Serial.println("find 2");
 
               
               }


      tcaselect(4);

      Serial.print("TCA Port #"); Serial.println(2);

      for (uint8_t addr = 0; addr<=127; addr++) {
        if (addr == TCAADDR) continue;

        Wire.beginTransmission(addr);
        if (!Wire.endTransmission()) {
          Serial.print("Found I2C 0x");  Serial.println(addr,HEX);
        }
      }

      if (!as7341.begin()){
               Serial.println("find 3");
               
               
               }            
         


      tcaselect(5);

      Serial.print("TCA Port #"); Serial.println(3);

      for (uint8_t addr = 0; addr<=127; addr++) {
        if (addr == TCAADDR) continue;

        Wire.beginTransmission(addr);
        if (!Wire.endTransmission()) {
          Serial.print("Found I2C 0x");  Serial.println(addr,HEX);
        }
      }

      if (!as7341.begin()){
               Serial.println("find 4");
               
               
               }            
         


  digitalWrite(SLED1, HIGH);
  digitalWrite(SLED2, HIGH);
  digitalWrite(SLED3, LOW);
  digitalWrite(SLED4, LOW);
  digitalWrite(SLED5, LOW);



  
 //  /* BLE */
while (!Serial);  // required for Flora & Micro
  delay(500);

  Serial.begin(9600);
  Serial.println(F("Adafruit Bluefruit Command <-> Data Mode Example"));
  Serial.println(F("------------------------------------------------"));

  /* Initialise the module */
  Serial.print(F("Initialising the Bluefruit LE module: "));
  

  if ( !ble.begin(VERBOSE_MODE) )
  {
    error(F("Couldn't find Bluefruit, make sure it's in CoMmanD mode & check wiring?"));
       while (1) {
  digitalWrite(SLED1, HIGH);
  digitalWrite(SLED2, LOW);
  digitalWrite(SLED3, LOW);
  digitalWrite(SLED4, LOW);
  digitalWrite(SLED5, LOW);
  delay(500);
  digitalWrite(SLED1, HIGH);
  digitalWrite(SLED2, HIGH);
  digitalWrite(SLED3, LOW);
  digitalWrite(SLED4, LOW);
  digitalWrite(SLED5, LOW);
  delay(500);
  }
  }
  Serial.println( F("OK!") );

  digitalWrite(SLED1, HIGH);
  digitalWrite(SLED2, HIGH);
  digitalWrite(SLED3, HIGH);
  digitalWrite(SLED4, LOW);
  digitalWrite(SLED5, LOW);

  if ( FACTORYRESET_ENABLE )
  {
    /* Perform a factory reset to make sure everything is in a known state */
    Serial.println(F("Performing a factory reset: "));
    if ( ! ble.factoryReset() ){
      error(F("Couldn't factory reset"));
    }
  }

  /* Disable command echo from Bluefruit */
  ble.echo(false);

  Serial.println("Requesting Bluefruit info:");
  
  /* Print Bluefruit information */
  ble.info();

  Serial.println(F("Please use Adafruit Bluefruit LE app to connect in UART mode"));
  Serial.println(F("Then Enter characters to send to Bluefruit"));
  Serial.println();

  ble.verbose(false);  // debug info is a little annoying after this point!

//  Wait for connection 
  while (! ble.isConnected()) {
      delay(500);
  }
  digitalWrite(SLED1, HIGH);
  digitalWrite(SLED2, HIGH);
  digitalWrite(SLED3, HIGH);
  digitalWrite(SLED4, HIGH);
  digitalWrite(SLED5, LOW);
  Serial.println(F("******************************"));

  // LED Activity command is only supported from 0.6.6
//  if ( ble.isVersionAtLeast(MINIMUM_FIRMWARE_VERSION) )
//  {
//    // Change Mode LED Activity
//    Serial.println(F("Change LED activity to " MODE_Adafruit_VCNL4010LED_BEHAVIOUR));
//    ble.sendCommandCheckOK("AT+HWModeLED=" MODE_LED_BEHAVIOUR);
//  }

  // Set module to DATA, mode
  Serial.println( F("Switching to DATA mode!") );
  ble.setMode(BLUEFRUIT_MODE_DATA);

  Serial.println(F("******************************"));
}




//LED



////////////////////////// Boolean values //////////////////////////
//bool sysInitStatus          = false;   //
//bool CartridgeDetectStatus  = false;
bool begincommandstatus       = false;
//bool SD_or_BLTstatus        = false;
//bool bluetoothDetectStatus    = false;
//bool SDdetectStatus         = false;
bool samplePushstatus           = false;
bool valvestatus           = false;
bool samplePrepstatus       =false;
bool sampleDispstatus       = false;
bool amplificationstatus      = false;
//bool ResultStatus           = false;
//bool  assayInStatus           = false;



////////////////////////// Functions //////////////////////////
void begincommand(bool &status);
//void salivaIn(bool &status);
void samplePrep(bool &status);
void sampleDisp(bool &status);
void samplePush(bool &status);
void valve(bool & status);
void amplification(bool &, const String);




///////////////Temperature function///////////


float temperature_read (int analog_pin)
{
  float temp;
  temp = analogRead(analog_pin);
  temp = 1023 / temp - 1;
  temp = SERIESRESISTOR / temp;  
  temp = temp / THERMISTORNOMINAL;     // (R/Ro)
  temp = log(temp);                  // ln(R/Ro)
  temp /= BCOEFFICIENT;                   // 1/B * ln(R/Ro)
  temp += 1.0 / (TEMPERATURENOMINAL + 273.15); // + (1/To)
  temp = 1.0 / temp;                 // Invert
  temp -= 273.15;                         // convert to C  
  return temp;
  }


////////////////////////// Loop //////////////////////////
void loop() {
   Serial.println("Wait begin command");
   while(! begincommandstatus  ) {
    begincommand(begincommandstatus); 
    //amplification(amplificationstatus);
    }

 //Serial.println("Sample Heating");
  while(!samplePrepstatus && begincommandstatus) {
           samplePrep(samplePrepstatus);         
  }

//Serial.println("sample dispensing");
  while(!sampleDispstatus && samplePrepstatus && begincommandstatus) {
           sampleDisp(sampleDispstatus);         
  }


  //Serial.println("open valve");
 while(!valvestatus &&  sampleDispstatus && samplePrepstatus && begincommandstatus)  {
   valve(valvestatus);
  }

  //Serial.println("sample pushing");
 while(!samplePushstatus &&valvestatus&&  sampleDispstatus && samplePrepstatus && begincommandstatus)  {
   samplePush(samplePushstatus);
  }
  
  Serial.println("Amplification");
 while(!amplificationstatus && valvestatus && sampleDispstatus && samplePrepstatus && begincommandstatus)  {
   amplification(amplificationstatus);
  }
   while(1){}
}

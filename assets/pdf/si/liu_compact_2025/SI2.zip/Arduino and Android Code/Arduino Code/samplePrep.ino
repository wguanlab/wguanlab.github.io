void samplePrep(bool &status){

  

  status = true;
  return;
  }





  


           
                  
                                     


 
   
                                    

void sampleDisp(bool &status){


    status = true;
    return;

}

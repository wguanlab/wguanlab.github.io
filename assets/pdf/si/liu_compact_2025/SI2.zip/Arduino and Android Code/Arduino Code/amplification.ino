void amplification(bool & status) {
    // 假设 TempA, TempB, TempC, TempD, TempE 和 TimeA, TimeB, TimeC, TimeD, TimeE 都已经定义
    // 定义循环次数
//Serial.print("beginStr: "); Serial.println(beginStr);

/*
const int cycle = 40;
const int TempA = 49;
const int TempB = 96;
const int TempC = 98;
const int TempD = 62;
const int TempE = 62;
const int TimeA = 300;
const int TimeB = 20;
const int TimeC = 3;
const int TimeD = 40;
const int TimeE = 0;

//delay(5000);

*/

const int cycle = Acycle;
const int TempA = ATempA;
const int TempB = ATempB;
const int TempC = ATempC;
const int TempD = ATempD;
const int TempE = ATempE;
const int TimeA = ATimeA;
const int TimeB = ATimeB;
const int TimeC = ATimeC;
const int TimeD = ATimeD;
const int TimeE = ATimeE;






  digitalWrite(SLED1, HIGH);
  digitalWrite(SLED2, HIGH);
  digitalWrite(SLED3, HIGH);
  digitalWrite(SLED4, HIGH);
  digitalWrite(SLED5, HIGH);



Serial.print("TempA: "); Serial.println(TempA);
Serial.print("TempB: "); Serial.println(TempB);
Serial.print("TempC: "); Serial.println(TempC);
Serial.print("TempD: "); Serial.println(TempD);
Serial.print("TempE: "); Serial.println(TempE);
Serial.print("TimeA: "); Serial.println(TimeA);
Serial.print("TimeB: "); Serial.println(TimeB);
Serial.print("TimeC: "); Serial.println(TimeC);
Serial.print("TimeD: "); Serial.println(TimeD);
Serial.print("TimeE: "); Serial.println(TimeE);
Serial.print("cycle: "); Serial.println(cycle);
//delay(1000);



    
     //  readOpticalSensor(); // 读取颜色传感器数据


       readOpticalSensor(); // 读取颜色传感器数据
     //TimeA = TimeB = TimeC = TimeD = TimeE = 10000;
    //TempA 阶段
    maintainTemperature(49, 100 );
    maintainTemperature(50, 200 ); // 维持 TempA 时间 TimeA 毫秒

    // TempB 阶段
    maintainTemperature(TempB, TimeB ); // 维持 TempB 时间 TimeB 毫秒

    // TempC 和 TempD 循环 cycle 次
    for (int i = 0; i < cycle; i++) {


     //  readOpticalSensor(); // 读取颜色传感器数据


        maintainTemperature(TempC, TimeC ); // 维持 TempC 时间 TimeC 毫秒
        //maintainTemperature(62, 10 ); // 维持 TempC 时间 TimeC 毫秒
        maintainTemperature(TempD, TimeD ); // 维持 TempD 时间 TimeD 毫秒
    }

    // TempE 阶段
    maintainTemperature(TempE, TimeE * 1000); // 维持 TempE 时间 TimeE 毫秒



    status = true;
}













void maintainTemperature(float targetTemp, long duration) {
    Setpoint = targetTemp;
    myPID.SetMode(AUTOMATIC); // 启用 PID 控制器
    myPID.SetOutputLimits(-255, 255);

    bool inTargetRange = false;
    uint32_t startTime = 0;

    while (true) {
        Input = temperature_read(THERMISTOR);
        myPID.Compute();

        // 根据 PID 输出调整加热器和风扇
        // 根据 PID 输出调整加热器和风扇

//Serial.print("out: "); Serial.print(Output);
        if (Output > 0) {
            heaterOutput = min(255, max(0, int(Output))); // 限制输出范围在 0 到 255
            //heaterOutput = 255;
            fanOutput = 0; // 当加热时关闭风扇
        } else {
            heaterOutput = 0; // 当冷却时关闭加热器
            //fanOutput = 255;
            fanOutput = min(255, max(0, int(-Output))); // 限制输出范围在 0 到 255
        }
        //analogWrite(PIDOUT, heaterOutput);
        analogWrite(HEATER, heaterOutput); // 调整加热器功率
        analogWrite(FAN, fanOutput);       // 调整风扇功率

        // 检查是否达到目标温度范围
        if (abs(Input - Setpoint) <= 1.5) {
            if (!inTargetRange) {
                // 一旦进入目标范围，记录开始时间并标记为已在范围内
               // Serial.print("Reach Temp Setting");
                inTargetRange = true;
                startTime = millis();
            }
        } else {
            // 如果温度离开目标范围，重置标志
            //inTargetRange = false;
        }

        // 如果在目标范围内并且已维持足够时间，则结束循环
        if (inTargetRange && (millis() - startTime)/1000 >= duration) {

          
            inTargetRange = false;
            analogWrite(HEATER, 0); // 调整加热器功率
            analogWrite(FAN, 0);       // 调整风扇功率
            
            break;
        }
        
        // 打印当前温度和输出
        Serial.print("set: "); Serial.print(targetTemp);
        Serial.print(" Maintaining Temp: "); Serial.print(Input);
        Serial.print(" Output: "); Serial.println(Output);
       // Serial.print(" Fan Output: "); Serial.println(fanOutput);//Serial.println((millis()- startTime)/1000);Serial.println(duration);

        // 短暂延迟以防止过快循环
        //delay(1000);
    }
}








void controlNeoPixelR(bool turnOn) {
    if (turnOn) {
        for (int pixel = 0; pixel < 4; pixel++) {
            NeoPixel.setPixelColor(pixel, NeoPixel.Color(255, 0, 0)); // 设置为红色
        }
        NeoPixel.setBrightness(100);
        NeoPixel.show();
        neoPixelActiveR = true;
        neoPixelStartTimeR = millis(); // 记录开始时间

        

    } else {
        NeoPixel.clear();
        NeoPixel.show();
        neoPixelActiveR = false;
    }
}

void controlNeoPixelG(bool turnOn) {
    if (turnOn) {
        for (int pixel = 0; pixel < 4; pixel++) {
            NeoPixel.setPixelColor(pixel, NeoPixel.Color(0, 255, 0)); // 设置为绿色
        }
        NeoPixel.setBrightness(100);
        NeoPixel.show();
        neoPixelActiveG = true;
        neoPixelStartTimeG = millis(); // 记录开始时间
    } else {
        NeoPixel.clear();
        NeoPixel.show();
        neoPixelActiveG = false;
    }
}

void controlNeoPixelB(bool turnOn) {
    if (turnOn) {
        for (int pixel = 0; pixel < 4; pixel++) {
            NeoPixel.setPixelColor(pixel, NeoPixel.Color(0, 0, 255)); // 设置为蓝色
        }
        NeoPixel.setBrightness(100);
        NeoPixel.show();
        neoPixelActiveB = true;
        neoPixelStartTimeB = millis(); // 记录开始时间
    } else {
        NeoPixel.clear();
        NeoPixel.show();
        neoPixelActiveB = false;
    }
}









void readOpticalSensor() {

  // 控制 NeoPixel 的颜色
  for (int color = 0; color < 3; color++) {
    // 打开相应颜色的 NeoPixel
    if (color == 0) controlNeoPixelR(true);
    else if (color == 1) controlNeoPixelG(true);
    else if (color == 2) controlNeoPixelB(true);

    neoPixelStartTime = millis();
    neoPixelActive = true;

    // 等待一秒
    while (millis() - neoPixelStartTime < neoPixelDuration) {
      // 可以插入一些轻量级的循环活动，但要避免长时间的阻塞
    }

    // 读取并处理四个光学模块的数据
for (int sensor = 2; sensor < 6; sensor++) {
    tcaselect(sensor);
    as7341.setATIME(100);
    as7341.setASTEP(99);
    as7341.setGain(AS7341_GAIN_512X);

    if (as7341.readAllChannels()) {
        // 读取并处理通道数据
       // for (int channel = 0; channel < channelCount; channel++) {


            // 根据sensor值选择正确的数组
            switch (sensor) {
                case 2:
                    sensorData1[0][color] = as7341.getChannel(AS7341_CHANNEL_415nm_F1);
                    sensorData1[1][color] = as7341.getChannel(AS7341_CHANNEL_445nm_F2);
                    sensorData1[2][color] = as7341.getChannel(AS7341_CHANNEL_480nm_F3);
                    sensorData1[3][color] = as7341.getChannel(AS7341_CHANNEL_515nm_F4);
                    sensorData1[4][color] = as7341.getChannel(AS7341_CHANNEL_555nm_F5);
                    sensorData1[5][color] = as7341.getChannel(AS7341_CHANNEL_590nm_F6);
                    sensorData1[6][color] = as7341.getChannel(AS7341_CHANNEL_630nm_F7);
                    sensorData1[7][color] = as7341.getChannel(AS7341_CHANNEL_680nm_F8);
                    sensorData1[8][color] = as7341.getChannel(AS7341_CHANNEL_CLEAR);
                    sensorData1[9][color] = as7341.getChannel(AS7341_CHANNEL_NIR);
                    
                    
                    break;
                case 3:
                    sensorData2[0][color] = as7341.getChannel(AS7341_CHANNEL_415nm_F1);
                    sensorData2[1][color] = as7341.getChannel(AS7341_CHANNEL_445nm_F2);
                    sensorData2[2][color] = as7341.getChannel(AS7341_CHANNEL_480nm_F3);
                    sensorData2[3][color] = as7341.getChannel(AS7341_CHANNEL_515nm_F4);
                    sensorData2[4][color] = as7341.getChannel(AS7341_CHANNEL_555nm_F5);
                    sensorData2[5][color] = as7341.getChannel(AS7341_CHANNEL_590nm_F6);
                    sensorData2[6][color] = as7341.getChannel(AS7341_CHANNEL_630nm_F7);
                    sensorData2[7][color] = as7341.getChannel(AS7341_CHANNEL_680nm_F8);
                    sensorData2[8][color] = as7341.getChannel(AS7341_CHANNEL_CLEAR);
                    sensorData2[9][color] = as7341.getChannel(AS7341_CHANNEL_NIR);
                    break;
                case 4:
                    sensorData3[0][color] = as7341.getChannel(AS7341_CHANNEL_415nm_F1);
                    sensorData3[1][color] = as7341.getChannel(AS7341_CHANNEL_445nm_F2);
                    sensorData3[2][color] = as7341.getChannel(AS7341_CHANNEL_480nm_F3);
                    sensorData3[3][color] = as7341.getChannel(AS7341_CHANNEL_515nm_F4);
                    sensorData3[4][color] = as7341.getChannel(AS7341_CHANNEL_555nm_F5);
                    sensorData3[5][color] = as7341.getChannel(AS7341_CHANNEL_590nm_F6);
                    sensorData3[6][color] = as7341.getChannel(AS7341_CHANNEL_630nm_F7);
                    sensorData3[7][color] = as7341.getChannel(AS7341_CHANNEL_680nm_F8);
                    sensorData3[8][color] = as7341.getChannel(AS7341_CHANNEL_CLEAR);
                    sensorData3[9][color] = as7341.getChannel(AS7341_CHANNEL_NIR);
                    break;
                case 5:
                    sensorData4[0][color] = as7341.getChannel(AS7341_CHANNEL_415nm_F1);
                    sensorData4[1][color] = as7341.getChannel(AS7341_CHANNEL_445nm_F2);
                    sensorData4[2][color] = as7341.getChannel(AS7341_CHANNEL_480nm_F3);
                    sensorData4[3][color] = as7341.getChannel(AS7341_CHANNEL_515nm_F4);
                    sensorData4[4][color] = as7341.getChannel(AS7341_CHANNEL_555nm_F5);
                    sensorData4[5][color] = as7341.getChannel(AS7341_CHANNEL_590nm_F6);
                    sensorData4[6][color] = as7341.getChannel(AS7341_CHANNEL_630nm_F7);
                    sensorData4[7][color] = as7341.getChannel(AS7341_CHANNEL_680nm_F8);
                    sensorData4[8][color] = as7341.getChannel(AS7341_CHANNEL_CLEAR);
                    sensorData4[9][color] = as7341.getChannel(AS7341_CHANNEL_NIR);
                    break;
            }
        //}
    }
    updateTemperatureControl();
}

    // 关闭当前颜色的 NeoPixel
    if (color == 0) controlNeoPixelR(false);
    else if (color == 1) controlNeoPixelG(false);
    else if (color == 2) controlNeoPixelB(false);

    neoPixelActive = false;
  }

  sendBluetoothSensorData();

  // 打印数据
for (int sensor = 0; sensor < 4; sensor++) {
    for (int channel = 0; channel < channelCount; channel++) {
        Serial.print("Sensor ");
        Serial.print(sensor + 1);
        Serial.print(" Channel ");
        Serial.print(channel + 1);
        Serial.print(" - R: ");

        // 选择正确的数组并打印相应的颜色值
        if (sensor == 0) {
            Serial.print(sensorData1[channel][0]); // 红色数据
            Serial.print(" G: ");
            Serial.print(sensorData1[channel][1]); // 绿色数据
            Serial.print(" B: ");
            Serial.println(sensorData1[channel][2]); // 蓝色数据
        } else if (sensor == 1) {
            Serial.print(sensorData2[channel][0]); // 红色数据
            Serial.print(" G: ");
            Serial.print(sensorData2[channel][1]); // 绿色数据
            Serial.print(" B: ");
            Serial.println(sensorData2[channel][2]); // 蓝色数据
        } else if (sensor == 2) {
            Serial.print(sensorData3[channel][0]); // 红色数据
            Serial.print(" G: ");
            Serial.print(sensorData3[channel][1]); // 绿色数据
            Serial.print(" B: ");
            Serial.println(sensorData3[channel][2]); // 蓝色数据
        } else if (sensor == 3) {
            Serial.print(sensorData4[channel][0]); // 红色数据
            Serial.print(" G: ");
            Serial.print(sensorData4[channel][1]); // 绿色数据
            Serial.print(" B: ");
            Serial.println(sensorData4[channel][2]); // 蓝色数据
        }
    }
}



  
}

/*


void sendBluetoothSensorData() {
    for (int sensor = 0; sensor < sensorCount; sensor++) {
        for (int channel = 0; channel < channelCount; channel++) {
            char tempStr[250]; // 临时字符串存储单个传感器数据

            // 格式化单个传感器数据
            //"Sensor %d Channel %d - R: %d G: %d B: %d\n", 
            sprintf(tempStr, "S %d C %d R %d G %d B %d", 
                    sensor + 1, 
                    channel + 1, 
                    sensorData[sensor][channel][0], // 红色数据
                    sensorData[sensor][channel][1], // 绿色数据
                    sensorData[sensor][channel][2]); // 蓝色数据

            // 通过蓝牙发送 formattedStr
            //ble.print("hello");
            ble.print(tempStr);

           // ble.print("Sensor 4 Channel 9 - R: 9999 G: 4048 B: 3932");
            

            //delay(500);
        }
    }
}


*/


void sendBluetoothSensorData() {
    int channel = 0; // 假设我们只关心第一通道
    char tempStr[100]; // 较短的字符串

    // 发送红色数据
    sprintf(tempStr, "R C%d %d %d %d %d", 
            channel + 1,
            sensorData[0][channel][0], // 传感器 1 红色数据
            sensorData[1][channel][0], // 传感器 2 红色数据
            sensorData[2][channel][0], // 传感器 3 红色数据
            sensorData[3][channel][0]); // 传感器 4 红色数据
    ble.print(tempStr);
    delay(500);

    // 发送绿色数据
    sprintf(tempStr, "G C%d %d %d %d %d", 
            channel + 1,
            sensorData[0][channel][1], // 传感器 1 绿色数据
            sensorData[1][channel][1], // 传感器 2 绿色数据
            sensorData[2][channel][1], // 传感器 3 绿色数据
            sensorData[3][channel][1]); // 传感器 4 绿色数据
    ble.print(tempStr);
    delay(500);

    // 发送蓝色数据
    sprintf(tempStr, "B C%d %d %d %d %d", 
            channel + 1,
            sensorData[0][channel][2], // 传感器 1 蓝色数据
            sensorData[1][channel][2], // 传感器 2 蓝色数据
            sensorData[2][channel][2], // 传感器 3 蓝色数据
            sensorData[3][channel][2]); // 传感器 4 蓝色数据
    ble.print(tempStr);

    // 可以选择延迟一段时间再发送下一组数据
    delay(500);
}






void updateTemperatureControl() {
    // 读取当前温度
    Input = temperature_read(THERMISTOR);
    myPID.Compute();

    // 根据 PID 输出调整加热器和风扇
    if (Output > 0) {
        heaterOutput = min(255, max(0, int(Output)));
        fanOutput = 0;
    } else {
        heaterOutput = 0;
        fanOutput = min(255, max(0, int(-Output)));
    }

    analogWrite(HEATER, heaterOutput);
    analogWrite(FAN, fanOutput);

    // 检查并更新温度维持状态
    // 注意：此处不包含延时，以避免阻塞
}

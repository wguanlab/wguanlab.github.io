void begincommand(bool &status) {
  String tempString = ""; // 用于存储临时字符串
  String timeString = ""; // 用于存储时间字符串
  String cycleString = ""; // 用于存储循环字符串

  while (ble.available()) {
    char c = (char)ble.read();

    // 根据当前字符和之前的字符串决定如何处理
    if (c == 'P' || c == 'L' || c == 'M') {
      if (c == 'P') {
        tempString += c;
        // 解析温度数据
        if (tempString.startsWith("Q")) {
          sscanf(tempString.c_str(), "Q %d %d %d %d %d P", 
                 &ATempA, &ATempB, &ATempC, &ATempD, &ATempE);
          Serial.println("Temperatures:");
          Serial.print("ATempA: "); Serial.println(ATempA);
          Serial.print("ATempB: "); Serial.println(ATempB);
          Serial.print("ATempC: "); Serial.println(ATempC);
          Serial.print("ATempD: "); Serial.println(ATempD);
          Serial.print("ATempE: "); Serial.println(ATempE);
        }
        tempString = ""; // 重置温度字符串
      } else if (c == 'L') {
        timeString += c;
        // 解析时间数据
        if (timeString.startsWith("A")) {
          sscanf(timeString.c_str(), "A %d %d %d %d %d L", 
                 &ATimeA, &ATimeB, &ATimeC, &ATimeD, &ATimeE);
          Serial.println("Times:");
          Serial.print("ATimeA: "); Serial.println(ATimeA);
          Serial.print("ATimeB: "); Serial.println(ATimeB);
          Serial.print("ATimeC: "); Serial.println(ATimeC);
          Serial.print("ATimeD: "); Serial.println(ATimeD);
          Serial.print("ATimeE: "); Serial.println(ATimeE);
        }
        timeString = ""; // 重置时间字符串
      } else if (c == 'M') {
        cycleString += c;
        // 解析循环数据
        if (cycleString.startsWith("Z")) {
          sscanf(cycleString.c_str(), "Z %d M", &Acycle);
          Serial.println("ACycle:");
          Serial.println(Acycle);

                  
        }
        cycleString = ""; // 重置循环字符串
        status = true;
      }
    } else {
      // 根据起始字符决定添加到哪个字符串
      if (c == 'Q') {
        tempString = "Q"; // 重新开始温度字符串
      } else if (c == 'A') {
        timeString = "A"; // 重新开始时间字符串
      } else if (c == 'Z') {
        cycleString = "Z"; // 重新开始循环字符串
      } else {
        // 根据当前活跃的字符串添加字符
        if (tempString.startsWith("Q")) {
          tempString += c;
        } else if (timeString.startsWith("A")) {
          timeString += c;
        } else if (cycleString.startsWith("Z")) {
          cycleString += c;
        }
      }
    }
  }
}

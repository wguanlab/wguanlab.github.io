void valve(bool & status){

          status = true;
          return;


  
}
